module.exports = {
  content: [
    "./resources/**/*.blade.php"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}