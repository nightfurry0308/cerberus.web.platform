<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign in</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>
    <div class="h-screen">
        <form class="w-72 m-auto table h-screen" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="table-cell align-middle">
                <h2 class="text-3xl mb-1">Sign in</h2>
                <p class="text-xs mb-4 text-stone-600">Stay updated on your professional world</p>

                <input id="email" type="email"
                    class="p-2 border border-solid border-stone-400 w-full rounded" name="email"
                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email">

                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-stone-500 absolute" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <input id="password" type="password"
                    class="p-2 border border-solid border-stone-400 w-full mt-4 rounded" name="password" required
                    autocomplete="current-password" placeholder="Password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="text-xs text-stone-500 absolute" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button type="submit" class="!bg-sky-600 text-white w-full p-2 rounded-full mt-4">
                    <?php echo e(__('Sign in')); ?>

                </button>

                <a href="<?php echo e(url('register')); ?>"
                    class="!bg-white text-stone-500 w-full p-2 rounded-full block border border-solid border-stone-400 text-center mt-4">
                    <?php echo e(__('Sign up')); ?>

                </a>
            </div>


        </form>

    </div>

</body>

</html>
<?php /**PATH D:\Workspace\cerberus\backend\resources\views/auth/login.blade.php ENDPATH**/ ?>